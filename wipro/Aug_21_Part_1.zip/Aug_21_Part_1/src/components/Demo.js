
const Demo = () => {

    const sayHello = () => {
        return "Welcome to React Testing...";
    } 

    return (
        <div>
            {sayHello()}
        </div>
    )
}

export default Demo;