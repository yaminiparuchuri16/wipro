import React from "react";

const TestComponent = () => {
      return (
        <div>
        <h1>Hello, World!</h1>
        <h2>Hi</h2>
        <h3>React Testing</h3>
       </div>

    )
}

export default TestComponent;