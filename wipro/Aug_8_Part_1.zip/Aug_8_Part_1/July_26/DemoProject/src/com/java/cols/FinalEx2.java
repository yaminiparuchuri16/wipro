package com.java.cols;

class First {
	public final void show() {
		System.out.println("Hi");
	}
}

class Second extends First {
	public void show() {
		System.out.println("Hello");
	}
}
public class FinalEx2 {

}
