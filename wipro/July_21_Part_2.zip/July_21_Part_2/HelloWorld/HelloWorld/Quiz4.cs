﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Quiz4
    {
        static void Main()
        {
            char ch = 'A';
            int a = ch;
            Console.WriteLine(a);
        }
    }
}
