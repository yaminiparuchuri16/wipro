﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Bitwise4
    {
        static void Main()
        {
            int a = 7;
            Console.WriteLine(~a);

            int b = -3;
            Console.WriteLine(~b);
        }
    }
}
