﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbsConEx
{
    internal class Uday : Employ
    {
        public Uday(int empno, string name, double basic) : base(empno, name, basic)
        {
        }
    }
}
