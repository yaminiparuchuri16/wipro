﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InhExamples
{
    internal class First
    {
        public void Show()
        {
            Console.WriteLine("Show Method From Class First...");
        }
    }
}
