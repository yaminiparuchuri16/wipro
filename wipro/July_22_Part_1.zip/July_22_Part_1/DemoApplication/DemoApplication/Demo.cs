﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApplication
{
    internal class Demo
    {
        public void Greeting()
        {
            Console.WriteLine("Welcome to Dotnet Programming...Trainer Prasanna...");
        }

        internal void Company()
        {
            Console.WriteLine("Company is Wipro...");
        }

        private void Trainer()
        {
            Console.WriteLine("Trainer is Prasanna Pappu...");
        }
    }
}
