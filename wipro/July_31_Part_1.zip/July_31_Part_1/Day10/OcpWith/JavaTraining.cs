﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OcpWith
{
    internal class JavaTraining : ITraining
    {
        public void Info()
        {
            Console.WriteLine("Java Training from Hexaware...");
        }

        public void Timing()
        {
            Console.WriteLine("Its from Night 9 to 12...");
        }
    }
}
