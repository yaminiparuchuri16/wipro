﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LspWIth
{
    internal class Mounika : Details
    {
        public override void ShowInfo()
        {
            Console.WriteLine("Hi I am Mounika...");
        }
    }
}
