﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LspWIth
{
    internal class Kusuma : Details
    {
        public override void ShowInfo()
        {
            Console.WriteLine("Hi I am Kusuma...");
        }
    }
}
