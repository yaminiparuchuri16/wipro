﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LspWIth
{
    internal class Ganesh : Details
    {
        public override void ShowInfo()
        {
            Console.WriteLine("HI I am Ganesh...");
        }
    }
}
