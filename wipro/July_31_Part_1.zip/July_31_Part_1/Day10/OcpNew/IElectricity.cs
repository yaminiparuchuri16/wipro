﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OcpNew
{
    internal interface IElectricity
    {
        string Payment(double billAmount);
    }
}
