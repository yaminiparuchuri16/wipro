﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IspWith
{
    internal class Murali : IPersonalDetails
    {
        public void ShowPersonalInfo()
        {
            Console.WriteLine("Hi I am Murali...Waiting for Project on Bench...");
        }
    }
}
