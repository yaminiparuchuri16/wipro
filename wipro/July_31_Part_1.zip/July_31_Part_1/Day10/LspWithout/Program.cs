﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LspWithout
{
    internal class Program
    {
        static void Main(string[] args)
        {
            First obj = new Second();
            obj.Show();
        }
    }
}
