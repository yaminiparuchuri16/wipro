﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DipWithout
{
    internal class DotnetTrg
    {
        public void TrainerName()
        {
            Console.WriteLine("Trainer Name is Chandra Sekhar...");
        }

        public void City()
        {
            Console.WriteLine("Location is from NewYork...");
        }
    }
}
