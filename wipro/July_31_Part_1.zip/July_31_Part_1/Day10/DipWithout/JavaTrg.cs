﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DipWithout
{
    internal class JavaTrg
    {
        public void TrainerName()
        {
            Console.WriteLine("Trainer Name is Prasanna...");
        }

        public void City()
        {
            Console.WriteLine("Location is from Hyderabad...");
        }

    }
}
