﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DipWith
{
    internal class DotnetInfo : ITrainerData
    {
        public void City()
        {
            Console.WriteLine("City is Hyderabad...");
        }

        public void Email()
        {
            Console.WriteLine("Email is prasanna@gmail.com");
        }

        public void Name()
        {
            Console.WriteLine("Name is Prasanna...");
        }
    }
}
