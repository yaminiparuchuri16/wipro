﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DipWith
{
    internal class JavaInfo : ITrainerData
    {
        public void City()
        {
            Console.WriteLine("City is Chennai...");
        }

        public void Email()
        {
            Console.WriteLine("Email is Chandra@gmail.com");
        }

        public void Name()
        {
            Console.WriteLine("Name is Chandra Sekhar...");
        }
    }
}
