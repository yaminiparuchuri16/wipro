﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OcpWithout
{
    internal class SapTraining
    {
        public void Show()
        {
            Console.WriteLine("Hi Its from SAP Authorized one we are giving...");
        }

        public void Timing()
        {
            Console.WriteLine("Its for ABAP 2 hrs BW 1 hr everyday (sat+sun)...");
        }
    }
}
