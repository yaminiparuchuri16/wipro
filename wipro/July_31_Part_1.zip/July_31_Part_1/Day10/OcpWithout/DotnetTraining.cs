﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OcpWithout
{
    internal class DotnetTraining
    {
        public void Show()
        {
            Console.WriteLine("Hi Its from Peers Technologies New Dotnet FSD Wipro Batch...");
        }

        public void Timing()
        {
            Console.WriteLine("Provision for fast track and and React with Industry Standards course...");
        }
    }
}
