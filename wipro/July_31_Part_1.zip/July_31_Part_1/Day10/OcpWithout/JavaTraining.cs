﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OcpWithout
{
    internal class JavaTraining
    {
        public void Show()
        {
            Console.WriteLine("Hi Its from Peers Technologies New Java Batch...");
        }

        public void Timing()
        {
            Console.WriteLine( "Provision for fast track and Realtime course...");
        }

    }
}
