﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IspWithout
{
    internal interface IEmployDetails
    {
        void PersonalDetails();
        void ProjectDetails();
        void AccountDetails();
    }
}
