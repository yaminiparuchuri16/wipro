let names : string[] =
[
    "Anusha","Uday","Charishma","Nandini",
    "Veera"
]

names.forEach(x => console.log(x));