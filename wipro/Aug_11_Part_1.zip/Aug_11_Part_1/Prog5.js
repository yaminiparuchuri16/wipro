function greeting(name) {
    console.log("Good Morning " + name);
}
greeting("Venkat");
