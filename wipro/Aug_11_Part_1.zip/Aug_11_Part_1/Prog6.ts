function sum(x : number, y : number) : number {
    return x + y;
}

function sub(x : number, y : number) : number {
    return x - y;
}

function mult(x : number, y : number) : number {
    return x * y;
}

console.log("Sum is " +sum(12,5));
console.log("Sub is  " +sub(12,5));
console.log("Mult is " +mult(12,5));