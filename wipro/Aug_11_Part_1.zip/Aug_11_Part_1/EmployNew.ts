export class Employ {
    constructor(public empno : number,public name :string, public basic : number){

    }
}