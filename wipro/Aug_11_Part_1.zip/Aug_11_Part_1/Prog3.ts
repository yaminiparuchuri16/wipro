let company: string = "Wipro"
let topic : string = "Typescript Programming"
let batch: string = "Dotnet FSD"
let data : any = "Hello World"

console.log("Company is " +company)
console.log("Topic is " +topic)
console.log("Batch is " +batch)
console.log("Status is " +data);
console.log(typeof(data));