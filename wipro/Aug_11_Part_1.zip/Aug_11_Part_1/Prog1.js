console.log("Welcome to Typescript");
