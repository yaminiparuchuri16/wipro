const show = (eno : number, name : string,company : string = "Wipro") => {
    console.log(eno + " " +name + " " +company)
}

show(1,"Prasanna","Deloitte");
show(2,"Kalyan");