function greeting(name : string){
    console.log("Good Morning " +name);
}

greeting("Venkat");