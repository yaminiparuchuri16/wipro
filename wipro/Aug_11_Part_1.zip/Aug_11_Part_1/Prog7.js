var employ1 = {
    empno: 1,
    name: "Prasanna",
    salary: 88234
};
console.log("Employ No ".concat(employ1.empno, " Employ Name ").concat(employ1.name, " Salary ").concat(employ1.salary, "  "));
