import React, {Component} from 'react';

const First = () => {
  return(
    <div>
      <p>This is My First Component in React...</p>
    </div>
  )
}

export default First;