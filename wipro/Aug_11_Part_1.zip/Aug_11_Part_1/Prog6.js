function sum(x, y) {
    return x + y;
}
function sub(x, y) {
    return x - y;
}
function mult(x, y) {
    return x * y;
}
console.log("Sum is " + sum(12, 5));
console.log("Sub is  " + sub(12, 5));
console.log("Mult is " + mult(12, 5));
