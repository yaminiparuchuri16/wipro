impor
const obj1 = new EmployNew(1, "Pralavi",84823);
console.log(`Employ No ${obj1.empno}  Employ Name ${obj1.name} 
                Salary ${obj1.basic}`)