var names = [
    "Anusha", "Uday", "Charishma", "Nandini",
    "Veera"
];
names.forEach(function (x) { return console.log(x); });
