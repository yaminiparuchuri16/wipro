const sayHello = () => {
    return "Welcome to TypeScript...";
}

console.log(sayHello());