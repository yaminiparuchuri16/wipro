var company = "Wipro";
var topic = "Typescript Programming";
var batch = "Dotnet FSD";
var data = "Hello World";
console.log("Company is " + company);
console.log("Topic is " + topic);
console.log("Batch is " + batch);
console.log("Status is " + data);
console.log(typeof (data));
