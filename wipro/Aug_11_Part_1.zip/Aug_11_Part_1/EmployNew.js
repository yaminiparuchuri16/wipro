"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Employ = void 0;
var Employ = /** @class */ (function () {
    function Employ(empno, name, basic) {
        this.empno = empno;
        this.name = name;
        this.basic = basic;
    }
    return Employ;
}());
exports.Employ = Employ;
