var Employ = /** @class */ (function () {
    function Employ() {
        this.empno = 1;
        this.name = "Rajesh";
        this.basic = 83823;
    }
    return Employ;
}());
var obj1 = new Employ();
console.log("Employ No ".concat(obj1.empno, " Employ Name ").concat(obj1.name, " Salary ").concat(obj1.basic));
