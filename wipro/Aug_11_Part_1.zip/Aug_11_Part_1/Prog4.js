var age = 28;
var faculty = "Prasanna";
console.log("Name is ".concat(faculty, " and Age is ").concat(age));
