let age : number = 28
let faculty : string = "Prasanna"
console.log(`Name is ${faculty} and Age is ${age}`)