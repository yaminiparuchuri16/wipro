class Employ {
    empno = 1;
    name = "Rajesh";
    basic = 83823
}

const obj1 = new Employ();
console.log(`Employ No ${obj1.empno} Employ Name ${obj1.name} Salary ${obj1.basic}`);