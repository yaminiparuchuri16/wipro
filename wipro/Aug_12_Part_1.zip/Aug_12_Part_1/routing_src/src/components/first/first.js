import React, {Component} from 'react';
import Menu from '../menu/menu';

const First = () => {
  return(
    <div>
      <Menu />
      <p>This is My First Component in React...</p>
    </div>
  )
}

export default First;