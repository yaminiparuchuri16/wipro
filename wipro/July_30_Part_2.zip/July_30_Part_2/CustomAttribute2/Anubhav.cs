﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttribute2
{

    [Vendor(vendorName:"Zomoto"), Vendor("AK Tifinis", premiumAmount =88323.44)]
    public class Anubhav
    {
    }
}
