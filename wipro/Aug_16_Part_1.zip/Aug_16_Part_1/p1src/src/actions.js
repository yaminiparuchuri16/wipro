export const rajesh = () => ({type:'RAJESH'})
export const narayana = () => ({type:'NARAYANA'})
export const mahi = () => ({type:'MAHI'})
