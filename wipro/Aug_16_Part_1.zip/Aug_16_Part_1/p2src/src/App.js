import logo from './logo.svg';
import './App.css';
import CounterComponent from './components/CounterComponent';

function App() {
  return (
    <div className="App">
      <CounterComponent />
    </div>
  );
}

export default App;
