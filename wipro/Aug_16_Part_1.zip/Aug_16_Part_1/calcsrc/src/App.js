import logo from './logo.svg';
import './App.css';
import Calculation from './components/Calculation';

function App() {
  return (
    <div className="App">
     <Calculation />
    </div>
  );
}

export default App;
