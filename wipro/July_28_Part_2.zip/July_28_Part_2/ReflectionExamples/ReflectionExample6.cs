﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: CLSCompliant(true)]
namespace ReflectionExamples
{

    [CLSCompliant(true)]
    public class ReflectionExample6
    {
        public void display() { }
        public void Hello() { }  

        public void method1() { }

        public void testEmploy() { }
        public void HowMany() { }   

        static void Main()
        {
            //new ReflectionExample6().HELLO();
        }
    }
}
