﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionExamples
{
    internal class Test
    {
        public int a;

        public void Hello()
        {
            Console.WriteLine("Hello...");
        }
    }
}
