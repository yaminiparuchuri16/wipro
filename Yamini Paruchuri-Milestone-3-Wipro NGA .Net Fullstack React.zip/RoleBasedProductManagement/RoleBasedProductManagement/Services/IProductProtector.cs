﻿namespace RoleBasedProductManagement.Services
{
    public interface IProductProtector
    {
        string Protect(decimal price);
        bool TryUnprotect(string protectedValue, out decimal price);
    }
}
